# CandleScan India

All-in-one Indian stock scanner on a single Streamlit page.